create
    definer = root@`%` function friend_function() returns varchar(50)
BEGIN
	DECLARE res_name VARCHAR(50) DEFAULT '空';
	SELECT beauty.`name` INTO res_name FROM beauty INNER JOIN boys ON beauty.boyfriend_id=boys.id 
	WHERE beauty.id=2;
	RETURN res_name;
END;

