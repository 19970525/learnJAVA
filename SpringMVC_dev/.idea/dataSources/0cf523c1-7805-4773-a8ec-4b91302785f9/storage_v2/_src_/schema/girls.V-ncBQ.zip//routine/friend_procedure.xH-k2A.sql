create
    definer = root@`%` procedure friend_procedure(IN women_name varchar(50))
BEGIN
	DECLARE aaa INT DEFAULT 5;
	SELECT * FROM beauty INNER JOIN boys ON beauty.boyfriend_id=boys.id
	WHERE beauty.`name`=women_name;
	
	WHILE aaa > 1 DO
			SET aaa = aaa-1;
			SELECT aaa;
	END WHILE;

	SELECT '--------------';

	IF aaa=1 THEN 
		SELECT aaa;
	ELSEIF aaa=2 THEN
		SELECT aaa;
	ELSE 
		SELECT aaa;
	END IF;
END;

