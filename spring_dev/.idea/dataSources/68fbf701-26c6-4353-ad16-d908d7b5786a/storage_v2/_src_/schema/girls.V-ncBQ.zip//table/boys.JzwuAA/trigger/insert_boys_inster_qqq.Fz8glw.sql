create definer = root@`%` trigger insert_boys_inster_qqq
    after insert
    on boys
    for each row
begin
	insert into qqq(username,`password`) values('boys','boys表添加一条新记录...');
end;

