create definer = root@`%` view qqq_view as
select `girls`.`qqq`.`id` AS `id`, `girls`.`qqq`.`username` AS `username`, `girls`.`qqq`.`password` AS `password`
from `girls`.`qqq`;

