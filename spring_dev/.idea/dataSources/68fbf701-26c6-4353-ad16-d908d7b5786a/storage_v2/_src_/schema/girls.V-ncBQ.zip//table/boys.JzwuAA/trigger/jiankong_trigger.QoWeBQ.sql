create definer = root@`%` trigger jiankong_trigger
    after insert
    on boys
    for each row
BEGIN
	DECLARE id_decl INT DEFAULT 0;
	DECLARE name_decl VARCHAR(10) DEFAULT '';
	DECLARE password_decl VARCHAR(10) DEFAULT '';
 	SELECT bb.`id`, bb.boyName , bb.userCP INTO id_decl, name_decl, password_decl FROM boys bb WHERE `id`=(SELECT MAX(b.`id`) FROM boys b);
	INSERT INTO qqq_view(`id`,username,`password`) VALUES(id_decl,name_decl,password_decl);
END;

